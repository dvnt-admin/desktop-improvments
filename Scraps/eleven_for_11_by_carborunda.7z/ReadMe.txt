Installation:

1. Download & install SecureUxTheme - "https://github.com/namazso/SecureUxTheme".

2. Restart system.

3. Copy files from "Theme" folder to "{SystemDisc}:\Windows\Resources\Themes".

4. Run SecureUxTheme and apply "Eleven+".

5. Enjoy!


Restoring back classic Start menu, Explorer and taskbar:

1. Download & install StartAllBack - "https://startallback.com".

2. Copy file from "StartAllBack" folder to "{SystemDisc}:\Program Files\StartAllBack\Styles".

3. Select "Eleven+" style in the program's settings.